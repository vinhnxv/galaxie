# SPDX-FileCopyrightText: 2026 Nguyễn Xuân Vĩnh
# SPDX-License-Identifier: AGPL-3.0-only

from typing import Any

from ._bridge import GalaxieError, request


async def call(name: str, input: Any, config: dict[str, Any] | None = None) -> Any:
    if not isinstance(name, str) or not name:
        raise GalaxieError("invalid")
    payload = {"name": name, "input": input}
    if config is not None:
        metadata = config.get("metadata") or {}
        configurable = config.get("configurable") or {}
        scope = metadata.get("langgraph_checkpoint_ns", configurable.get("checkpoint_ns"))
        if scope is not None:
            if not isinstance(scope, str):
                raise GalaxieError("invalid")
            payload["effectScope"] = scope
    return await request("capability", payload)
